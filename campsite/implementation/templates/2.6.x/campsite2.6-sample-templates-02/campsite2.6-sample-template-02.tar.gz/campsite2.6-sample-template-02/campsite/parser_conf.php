<?php

$Campsite['PARSER_PORT'] = '2001';
$Campsite['PARSER_MAX_THREADS'] = '0';

$CampsiteVars['parser'] = array('PARSER_PORT', 'PARSER_MAX_THREADS');

?>