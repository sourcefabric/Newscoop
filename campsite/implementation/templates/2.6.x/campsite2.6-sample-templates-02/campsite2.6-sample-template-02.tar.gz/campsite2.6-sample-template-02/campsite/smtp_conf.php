<?php

$Campsite['SMTP_SERVER_ADDRESS'] = '127.0.0.1';
$Campsite['SMTP_SERVER_PORT'] = '25';

$CampsiteVars['smtp'] = array('SMTP_SERVER_ADDRESS', 'SMTP_SERVER_PORT');

?>