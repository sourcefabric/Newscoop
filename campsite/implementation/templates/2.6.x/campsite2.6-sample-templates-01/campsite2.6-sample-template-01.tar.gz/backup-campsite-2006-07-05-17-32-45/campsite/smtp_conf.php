<?php

$Campsite['SMTP_SERVER_ADDRESS'] = 'localhost';
$Campsite['SMTP_SERVER_PORT'] = '25';

$CampsiteVars['smtp'] = array('SMTP_SERVER_ADDRESS', 'SMTP_SERVER_PORT');

?>