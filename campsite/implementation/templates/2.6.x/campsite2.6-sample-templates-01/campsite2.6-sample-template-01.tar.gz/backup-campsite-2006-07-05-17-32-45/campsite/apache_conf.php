<?php

$Campsite['APACHE_USER'] = 'www-data';
$Campsite['APACHE_GROUP'] = 'www-data';

$CampsiteVars['apache'] = array('APACHE_USER', 'APACHE_GROUP');

?>