<?php

$Campsite['DATABASE_NAME'] = 'campsite';
$Campsite['DATABASE_SERVER_ADDRESS'] = 'localhost';
$Campsite['DATABASE_SERVER_PORT'] = '0';
$Campsite['DATABASE_USER'] = 'root';
$Campsite['DATABASE_PASSWORD'] = '';

$CampsiteVars['database'] = array('DATABASE_NAME', 'DATABASE_SERVER_ADDRESS', 'DATABASE_SERVER_PORT', 'DATABASE_USER', 'DATABASE_PASSWORD');

?>